package com.macheal.app.prospect.security.service;


import com.macheal.app.prospect.security.repository.entity.Role;

public interface RoleService {

    Role save(final String name);
}
