package com.macheal.app.prospect.feature.event.service;

public interface EventService {
}
