package com.macheal.app.prospect.notification.dto;

public enum NotificationType {
    EMAIL
}
