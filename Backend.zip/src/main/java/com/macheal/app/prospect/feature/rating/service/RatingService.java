package com.macheal.app.prospect.feature.rating.service;

public class RatingService {
}
