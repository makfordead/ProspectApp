package com.macheal.app.prospect.security.service;

public interface VerifyEmailService {
    void verifyEmail(final String token);
}
