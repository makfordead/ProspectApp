package com.macheal.app.prospect.feature.event.service.impl;

public class EventServiceImpl {

//    NotificationService<EmailDataRequest> notificationService;
//
//    public void test() {
//        final User user = new User();
//        EmailDataRequest r = EmailDataRequest.builder().content(Map.of("user", user)).build();
//        notificationService.prepareAndSendMessage(r, NotificationType.EMAIL,
//                Locale.forLanguageTag("en"), "/user-confirm-register.ftl");
//        EventType.valueOf(EventType.CONFIRM_EVENT.name()).getCode();
//   }
}
