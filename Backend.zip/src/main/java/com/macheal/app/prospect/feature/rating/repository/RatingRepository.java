package com.macheal.app.prospect.feature.rating.repository;

public interface RatingRepository {
}
